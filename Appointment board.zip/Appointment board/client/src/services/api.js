const BASE_URL = '/api/appointments';

export async function fetchAppointments(filters = {}) {
  const params = new URLSearchParams();
  if (filters.date) params.append('date', filters.date);
  if (filters.status && filters.status !== 'all') params.append('status', filters.status);
  if (filters.search) params.append('search', filters.search);

  const url = params.toString() ? `${BASE_URL}?${params.toString()}` : BASE_URL;
  const res = await fetch(url);
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to fetch appointments');
  }
  return data.data;
}

export async function createAppointment(appointmentData) {
  const res = await fetch(BASE_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(appointmentData),
  });
  const data = await res.json();
  if (!res.ok) {
    const error = new Error(data.error || 'Failed to schedule appointment');
    error.status = res.status;
    error.conflictingAppointment = data.conflictingAppointment;
    error.errors = data.errors;
    throw error;
  }
  return data;
}

export async function updateAppointment(id, appointmentData) {
  const res = await fetch(`${BASE_URL}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(appointmentData),
  });
  const data = await res.json();
  if (!res.ok) {
    const error = new Error(data.error || 'Failed to update appointment');
    error.status = res.status;
    error.conflictingAppointment = data.conflictingAppointment;
    error.errors = data.errors;
    throw error;
  }
  return data;
}

export async function completeAppointment(id) {
  const res = await fetch(`${BASE_URL}/${id}/complete`, {
    method: 'PATCH',
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to mark appointment as completed');
  }
  return data;
}

export async function cancelAppointment(id) {
  const res = await fetch(`${BASE_URL}/${id}/cancel`, {
    method: 'PATCH',
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to cancel appointment');
  }
  return data;
}

export async function resetAppointments() {
  const res = await fetch(`${BASE_URL}/reset`, {
    method: 'POST',
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to reset appointments');
  }
  return data.data;
}

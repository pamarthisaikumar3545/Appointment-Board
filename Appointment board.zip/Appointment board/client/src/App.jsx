import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import FilterBar from './components/FilterBar';
import BoardView from './components/BoardView';
import ListView from './components/ListView';
import AppointmentModal from './components/AppointmentModal';
import InfoModal from './components/InfoModal';
import Toast from './components/Toast';
import {
  fetchAppointments,
  createAppointment,
  updateAppointment,
  completeAppointment,
  cancelAppointment,
  resetAppointments
} from './services/api';
import { Loader2 } from 'lucide-react';

export default function App() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState('board');
  const [filters, setFilters] = useState({
    date: '',
    status: 'all',
    search: ''
  });

  const [toast, setToast] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAppointment, setEditingAppointment] = useState(null);
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);

  // Load appointments from backend
  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      const data = await fetchAppointments(filters);
      setAppointments(data);
    } catch (err) {
      setToast({
        type: 'error',
        title: 'Network Error',
        message: err.message || 'Could not load appointments.'
      });
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Overall counts (unfiltered by status, but respects date & search if specified)
  const [allCountAppointments, setAllCountAppointments] = useState([]);
  useEffect(() => {
    fetchAppointments({ date: filters.date, search: filters.search })
      .then(res => setAllCountAppointments(res))
      .catch(() => {});
  }, [filters.date, filters.search, appointments]);

  const counts = {
    all: allCountAppointments.length,
    scheduled: allCountAppointments.filter(a => a.status === 'scheduled').length,
    completed: allCountAppointments.filter(a => a.status === 'completed').length,
    cancelled: allCountAppointments.filter(a => a.status === 'cancelled').length
  };

  // Handlers
  const handleAddNew = () => {
    setEditingAppointment(null);
    setIsModalOpen(true);
  };

  const handleEdit = (appointment) => {
    setEditingAppointment(appointment);
    setIsModalOpen(true);
  };

  const handleModalSubmit = async (formData) => {
    if (editingAppointment) {
      const res = await updateAppointment(editingAppointment.id, formData);
      setToast({
        type: 'success',
        title: 'Appointment Updated',
        message: `Successfully updated "${res.data.title}".`
      });
    } else {
      const res = await createAppointment(formData);
      setToast({
        type: 'success',
        title: 'Appointment Scheduled',
        message: `"${res.data.title}" has been added to the board.`
      });
    }
    await loadData();
  };

  const handleComplete = async (id) => {
    try {
      const res = await completeAppointment(id);
      setToast({
        type: 'success',
        title: 'Marked Completed',
        message: `"${res.data.title}" has been marked as completed.`
      });
      await loadData();
    } catch (err) {
      setToast({
        type: 'error',
        title: 'Action Failed',
        message: err.message || 'Could not complete appointment.'
      });
    }
  };

  const handleCancel = async (id) => {
    try {
      const res = await cancelAppointment(id);
      setToast({
        type: 'info',
        title: 'Appointment Cancelled',
        message: `"${res.data.title}" was cancelled. Its time slot is now open.`
      });
      await loadData();
    } catch (err) {
      setToast({
        type: 'error',
        title: 'Action Failed',
        message: err.message || 'Could not cancel appointment.'
      });
    }
  };

  const handleResetData = async () => {
    try {
      await resetAppointments();
      setToast({
        type: 'info',
        title: 'Reset Complete',
        message: 'Appointments board has been re-initialized with sample data.'
      });
      await loadData();
    } catch (err) {
      setToast({
        type: 'error',
        title: 'Reset Failed',
        message: err.message || 'Could not reset appointments.'
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Top Header Navigation */}
      <Header
        appointments={allCountAppointments}
        onOpenAddModal={handleAddNew}
        onOpenInfoModal={() => setIsInfoModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Filter and Control Bar */}
        <FilterBar
          filters={filters}
          onFilterChange={setFilters}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          onResetData={handleResetData}
          appointmentCounts={counts}
        />

        {/* Loading Spinner or View Modes */}
        {loading ? (
          <div className="h-64 flex flex-col items-center justify-center text-slate-400 gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
            <span className="text-xs font-medium text-slate-500">Loading appointments...</span>
          </div>
        ) : viewMode === 'board' ? (
          <BoardView
            appointments={appointments}
            onEdit={handleEdit}
            onComplete={handleComplete}
            onCancel={handleCancel}
            onAddNew={handleAddNew}
          />
        ) : (
          <ListView
            appointments={appointments}
            onEdit={handleEdit}
            onComplete={handleComplete}
            onCancel={handleCancel}
            onAddNew={handleAddNew}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Appointment Board &bull; Full Stack Developer Intern Practical Task</span>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsInfoModalOpen(true)}
              className="text-indigo-600 hover:text-indigo-800 font-medium underline underline-offset-2"
            >
              How It Works &amp; Assumptions
            </button>
            <span>&bull;</span>
            <button
              onClick={handleResetData}
              className="text-slate-500 hover:text-slate-800 underline underline-offset-2"
            >
              Reset Demo Data
            </button>
          </div>
        </div>
      </footer>

      {/* Modals & Toasts */}
      <AppointmentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleModalSubmit}
        initialData={editingAppointment}
        existingAppointments={allCountAppointments}
      />

      <InfoModal
        isOpen={isInfoModalOpen}
        onClose={() => setIsInfoModalOpen(false)}
      />

      <Toast
        toast={toast}
        onClose={() => setToast(null)}
      />
    </div>
  );
}

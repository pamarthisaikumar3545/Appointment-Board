import React from 'react';
import AppointmentCard from './AppointmentCard';
import { CalendarClock, CheckCircle2, Ban } from 'lucide-react';

export default function BoardView({
  appointments = [],
  onEdit,
  onComplete,
  onCancel,
  onAddNew
}) {
  const scheduled = appointments.filter(a => a.status === 'scheduled');
  const completed = appointments.filter(a => a.status === 'completed');
  const cancelled = appointments.filter(a => a.status === 'cancelled');

  const columns = [
    {
      id: 'scheduled',
      title: 'Scheduled / Upcoming',
      icon: CalendarClock,
      badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
      headerBorder: 'border-blue-500',
      items: scheduled,
      emptyMessage: 'No scheduled appointments.'
    },
    {
      id: 'completed',
      title: 'Completed',
      icon: CheckCircle2,
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      headerBorder: 'border-emerald-500',
      items: completed,
      emptyMessage: 'No completed appointments yet.'
    },
    {
      id: 'cancelled',
      title: 'Cancelled',
      icon: Ban,
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-200',
      headerBorder: 'border-rose-400',
      items: cancelled,
      emptyMessage: 'No cancelled appointments.'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
      {columns.map(col => {
        const Icon = col.icon;
        return (
          <div
            key={col.id}
            className="bg-slate-100/70 rounded-2xl p-4 border border-slate-200/80 flex flex-col min-h-[420px]"
          >
            {/* Column Header */}
            <div className={`flex items-center justify-between pb-3 mb-3 border-b-2 ${col.headerBorder}`}>
              <div className="flex items-center gap-2">
                <Icon className="w-4 h-4 text-slate-600" />
                <h2 className="font-bold text-sm text-slate-800 tracking-tight">{col.title}</h2>
              </div>
              <span className={`text-xs px-2 py-0.5 rounded-full font-bold border ${col.badgeColor}`}>
                {col.items.length}
              </span>
            </div>

            {/* Appointment Cards */}
            <div className="space-y-3 flex-1">
              {col.items.length > 0 ? (
                col.items.map(appointment => (
                  <AppointmentCard
                    key={appointment.id}
                    appointment={appointment}
                    onEdit={onEdit}
                    onComplete={onComplete}
                    onCancel={onCancel}
                  />
                ))
              ) : (
                <div className="h-44 flex flex-col items-center justify-center text-center p-4 border border-dashed border-slate-300 rounded-xl">
                  <p className="text-xs text-slate-400 font-medium">{col.emptyMessage}</p>
                  {col.id === 'scheduled' && (
                    <button
                      onClick={onAddNew}
                      className="mt-2 text-xs text-indigo-600 hover:text-indigo-800 font-semibold underline underline-offset-2"
                    >
                      + Schedule one now
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

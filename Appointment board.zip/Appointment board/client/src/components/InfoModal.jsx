import React, { useEffect } from 'react';
import { X, CheckCircle2, ShieldAlert, Clock, Layers, HelpCircle } from 'lucide-react';

export default function InfoModal({ isOpen, onClose }) {
  useEffect(() => {
    function handleKeyDown(e) {
      if (e.key === 'Escape' && isOpen) onClose();
    }
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div 
        className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] overflow-y-auto border border-slate-100"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby="info-modal-title"
      >
        {/* Header */}
        <div className="sticky top-0 bg-white/95 backdrop-blur-xs px-6 py-4 border-b border-slate-100 flex items-center justify-between z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 id="info-modal-title" className="text-lg font-bold text-slate-900">
                Application Overview & Engineering Assumptions
              </h2>
              <p className="text-xs text-slate-500">
                Documentation of behavior, business logic, and scheduling rules
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 text-slate-700 text-sm leading-relaxed">
          {/* Section 1: How the App Works */}
          <section>
            <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-600 flex items-center gap-1.5 mb-2">
              <Layers className="w-4 h-4" />
              1. How the Application Works
            </h3>
            <ul className="space-y-2 text-xs text-slate-600 pl-1">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-500 flex-shrink-0 mt-0.5" />
                <span>
                  <strong>Board & List Views:</strong> Appointments can be viewed as an interactive Kanban board with 3 status columns (Scheduled, Completed, Cancelled) or as a chronological date-grouped timeline list.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-500 flex-shrink-0 mt-0.5" />
                <span>
                  <strong>Adding & Editing:</strong> Users can schedule new meetings with title, host, date, start time, end time, and description, or update existing appointments anytime.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-500 flex-shrink-0 mt-0.5" />
                <span>
                  <strong>Status Lifecycle:</strong> Appointments start as <span className="text-blue-600 font-semibold">Scheduled</span>, and can be marked as <span className="text-emerald-600 font-semibold">Completed</span> or <span className="text-rose-600 font-semibold">Cancelled</span>.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-500 flex-shrink-0 mt-0.5" />
                <span>
                  <strong>Filtering & Search:</strong> Immediate filtering by specific date (with "Today" shortcut), status pills, or full-text query matching title and descriptions.
                </span>
              </li>
            </ul>
          </section>

          {/* Section 2: Conflict Prevention */}
          <section className="bg-amber-50/60 p-4 rounded-xl border border-amber-200/80">
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-900 flex items-center gap-1.5 mb-2">
              <ShieldAlert className="w-4 h-4 text-amber-700" />
              2. Time Slot Conflict Prevention Algorithm
            </h3>
            <p className="text-xs text-amber-950 mb-2">
              To prevent two appointments from using the same time slot, both client-side and server-side validation run exact overlap checking on the same date:
            </p>
            <div className="bg-white/80 p-2.5 rounded-lg border border-amber-200 text-xs font-mono text-slate-800 mb-2">
              (startTimeA &lt; endTimeB) &amp;&amp; (startTimeB &lt; endTimeA)
            </div>
            <p className="text-xs text-amber-900">
              When a conflict is detected, scheduling is blocked with an HTTP 409 Conflict status and a clear alert identifying the exact conflicting meeting and time range.
            </p>
          </section>

          {/* Section 3: Assumptions Made */}
          <section>
            <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-600 flex items-center gap-1.5 mb-2">
              <Clock className="w-4 h-4" />
              3. Key Assumptions Made
            </h3>
            <div className="space-y-2.5 text-xs text-slate-600">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-semibold text-slate-800">Assumption 1: Back-to-Back Appointments</p>
                <p className="mt-0.5 text-slate-600">
                  If Meeting A ends at 11:00 AM and Meeting B starts at 11:00 AM, they do <strong>not</strong> conflict. Meeting boundaries can touch without overlap.
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-semibold text-slate-800">Assumption 2: Cancelled Appointments &amp; Slot Availability</p>
                <p className="mt-0.5 text-slate-600">
                  Cancelled appointments remain permanently visible on the board (marked with strikethrough, muted colors, and a red badge). However, their time slot is released so new meetings can be scheduled at that time.
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-semibold text-slate-800">Assumption 3: Shared Team Resource</p>
                <p className="mt-0.5 text-slate-600">
                  The appointment board represents a shared calendar or conference room for a small team, meaning conflict prevention applies to all active appointments across the team schedule.
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-semibold text-slate-800">Assumption 4: Self-Exclusion on Updates</p>
                <p className="mt-0.5 text-slate-600">
                  When editing an appointment, its own existing record is excluded from conflict checking, allowing updates to title, host, or notes without triggering false conflict errors.
                </p>
              </div>
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors"
          >
            Got it, close
          </button>
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import { CalendarRange, Plus, HelpCircle, CheckCircle2, Clock, Ban } from 'lucide-react';

export default function Header({
  appointments = [],
  onOpenAddModal,
  onOpenInfoModal
}) {
  const total = appointments.length;
  const scheduledCount = appointments.filter(a => a.status === 'scheduled').length;
  const completedCount = appointments.filter(a => a.status === 'completed').length;
  const cancelledCount = appointments.filter(a => a.status === 'cancelled').length;

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          {/* Logo and Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-200 flex-shrink-0">
              <CalendarRange className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-slate-900 tracking-tight">Team Appointment Board</h1>
                <span className="px-2 py-0.5 text-[10px] font-semibold tracking-wide uppercase bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-full">
                  Team Sync
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Shared schedule for team meetings, demos, reviews & appointments
              </p>
            </div>
          </div>

          {/* Stats pills & CTA buttons */}
          <div className="flex items-center gap-3 flex-wrap">
            {/* Quick Metrics */}
            <div className="hidden lg:flex items-center gap-2 bg-slate-50 p-1.5 rounded-xl border border-slate-200 text-xs">
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white shadow-xs">
                <span className="text-slate-500 font-medium">Total:</span>
                <span className="font-bold text-slate-900">{total}</span>
              </div>

              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-blue-700">
                <Clock className="w-3.5 h-3.5 text-blue-500" />
                <span className="font-semibold">{scheduledCount} Scheduled</span>
              </div>

              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-emerald-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                <span className="font-semibold">{completedCount} Done</span>
              </div>

              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-rose-700">
                <Ban className="w-3.5 h-3.5 text-rose-500" />
                <span className="font-semibold">{cancelledCount} Cancelled</span>
              </div>
            </div>

            {/* How it works button */}
            <button
              onClick={onOpenInfoModal}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors"
              title="View how the board works and assumptions made"
            >
              <HelpCircle className="w-4 h-4 text-slate-500" />
              <span>How It Works</span>
            </button>

            {/* Add Appointment Button */}
            <button
              onClick={onOpenAddModal}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] rounded-xl shadow-sm hover:shadow-indigo-200 hover:shadow-md transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Appointment</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}

import React from 'react';
import AppointmentCard from './AppointmentCard';
import { Calendar, CalendarPlus } from 'lucide-react';
import { formatDatePretty, getRelativeDateLabel } from '../utils/timeUtils';

export default function ListView({
  appointments = [],
  onEdit,
  onComplete,
  onCancel,
  onAddNew
}) {
  if (appointments.length === 0) {
    return (
      <div className="bg-white rounded-2xl p-12 border border-slate-200 text-center max-w-lg mx-auto">
        <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-3">
          <Calendar className="w-6 h-6" />
        </div>
        <h3 className="text-base font-bold text-slate-800 mb-1">No appointments found</h3>
        <p className="text-xs text-slate-500 mb-4">
          There are no appointments matching your current filters.
        </p>
        <button
          onClick={onAddNew}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors"
        >
          <CalendarPlus className="w-4 h-4" />
          Add New Appointment
        </button>
      </div>
    );
  }

  // Group appointments by date
  const groupedByDate = appointments.reduce((acc, apt) => {
    const key = apt.date;
    if (!acc[key]) acc[key] = [];
    acc[key].push(apt);
    return acc;
  }, {});

  const sortedDates = Object.keys(groupedByDate).sort();

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {sortedDates.map(date => {
        const items = groupedByDate[date];
        const relativeLabel = getRelativeDateLabel(date);
        const prettyDate = formatDatePretty(date);

        return (
          <div key={date} className="relative">
            {/* Date Group Header */}
            <div className="sticky top-20 z-10 bg-slate-50/95 backdrop-blur-xs py-2 mb-3 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-500"></span>
                <h3 className="font-bold text-sm text-slate-800">
                  {relativeLabel !== prettyDate ? `${relativeLabel} (${prettyDate})` : prettyDate}
                </h3>
              </div>
              <span className="text-xs font-semibold text-slate-500 bg-slate-200/80 px-2 py-0.5 rounded-full">
                {items.length} {items.length === 1 ? 'appointment' : 'appointments'}
              </span>
            </div>

            {/* List of cards for this date */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {items.map(appointment => (
                <AppointmentCard
                  key={appointment.id}
                  appointment={appointment}
                  onEdit={onEdit}
                  onComplete={onComplete}
                  onCancel={onCancel}
                />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, User, AlignLeft, AlertTriangle } from 'lucide-react';
import { getTodayDateString } from '../utils/timeUtils';

export default function AppointmentModal({
  isOpen,
  onClose,
  onSubmit,
  initialData = null,
  existingAppointments = []
}) {
  const isEditing = Boolean(initialData);

  const [formData, setFormData] = useState({
    title: '',
    teamMember: '',
    date: getTodayDateString(),
    startTime: '09:00',
    endTime: '10:00',
    description: ''
  });

  const [errorMsg, setErrorMsg] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (initialData) {
      setFormData({
        title: initialData.title || '',
        teamMember: initialData.teamMember || '',
        date: initialData.date || getTodayDateString(),
        startTime: initialData.startTime || '09:00',
        endTime: initialData.endTime || '10:00',
        description: initialData.description || ''
      });
    } else {
      setFormData({
        title: '',
        teamMember: '',
        date: getTodayDateString(),
        startTime: '10:00',
        endTime: '11:00',
        description: ''
      });
    }
    setErrorMsg('');
  }, [initialData, isOpen]);

  // Handle ESC key to close
  useEffect(() => {
    function handleKeyDown(e) {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    }
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Real-time client-side checks
  const timeInvalid = formData.startTime && formData.endTime && formData.endTime <= formData.startTime;

  // Real-time overlap conflict advisory check
  const checkOverlapPreview = () => {
    if (timeInvalid || !formData.date || !formData.startTime || !formData.endTime) return null;

    const [s1h, s1m] = formData.startTime.split(':').map(Number);
    const [e1h, e1m] = formData.endTime.split(':').map(Number);
    const startMin = s1h * 60 + s1m;
    const endMin = e1h * 60 + e1m;

    return existingAppointments.find(apt => {
      if (apt.date !== formData.date) return false;
      if (apt.status === 'cancelled') return false;
      if (isEditing && apt.id === initialData?.id) return false;

      const [s2h, s2m] = apt.startTime.split(':').map(Number);
      const [e2h, e2m] = apt.endTime.split(':').map(Number);
      const s2Min = s2h * 60 + s2m;
      const e2Min = e2h * 60 + e2m;

      return startMin < e2Min && s2Min < endMin;
    });
  };

  const previewConflict = checkOverlapPreview();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    if (!formData.title.trim()) {
      setErrorMsg('Please enter an appointment title.');
      return;
    }

    if (!formData.date) {
      setErrorMsg('Please select a date.');
      return;
    }

    if (timeInvalid) {
      setErrorMsg('End time must be strictly after the start time.');
      return;
    }

    setSubmitting(true);
    try {
      await onSubmit(formData);
      onClose();
    } catch (err) {
      setErrorMsg(err.message || 'An error occurred while saving.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div 
        className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 transform transition-all"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-slate-50 to-white">
          <div>
            <h2 id="modal-title" className="text-xl font-bold text-slate-800">
              {isEditing ? 'Edit Appointment' : 'Schedule New Appointment'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {isEditing ? 'Update details or reschedule this slot' : 'Fill in the meeting information to reserve a time slot'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Server / Validation Error Alert */}
          {errorMsg && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-sm flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{errorMsg}</div>
            </div>
          )}

          {/* Real-time Conflict Warning Banner */}
          {!errorMsg && previewConflict && (
            <div className="p-3.5 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl text-xs flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold">Time Conflict Warning: </span>
                This slot overlaps with "{previewConflict.title}" ({previewConflict.startTime} - {previewConflict.endTime}). Please pick an open time.
              </div>
            </div>
          )}

          {/* Title */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1.5">
              Appointment Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              autoFocus
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g. Design Review, Sprint Planning, Client Sync"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 placeholder-slate-400"
            />
          </div>

          {/* Team Member / Attendee */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-slate-400" />
              Team Member / Host
            </label>
            <input
              type="text"
              value={formData.teamMember}
              onChange={(e) => setFormData({ ...formData, teamMember: e.target.value })}
              placeholder="e.g. Sarah Jenkins or Team Lead"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 placeholder-slate-400"
            />
          </div>

          {/* Date Picker */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              Date <span className="text-rose-500">*</span>
            </label>
            <input
              type="date"
              required
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white"
            />
          </div>

          {/* Start and End Times */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                Start Time <span className="text-rose-500">*</span>
              </label>
              <input
                type="time"
                required
                value={formData.startTime}
                onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                End Time <span className="text-rose-500">*</span>
              </label>
              <input
                type="time"
                required
                value={formData.endTime}
                onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-slate-900 text-sm focus:outline-none focus:ring-2 bg-white ${
                  timeInvalid
                    ? 'border-rose-300 focus:ring-rose-500 focus:border-rose-500 bg-rose-50/40'
                    : 'border-slate-200 focus:ring-indigo-500 focus:border-indigo-500'
                }`}
              />
            </div>
          </div>

          {timeInvalid && (
            <p className="text-xs text-rose-600 font-medium">
              End time must be after start time ({formData.startTime}).
            </p>
          )}

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
              <AlignLeft className="w-3.5 h-3.5 text-slate-400" />
              Description / Agenda
            </label>
            <textarea
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Provide context, meeting link, or key discussion points..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 placeholder-slate-400 resize-none"
            />
          </div>

          {/* Actions */}
          <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || timeInvalid}
              className="px-5 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-sm hover:shadow transition-all"
            >
              {submitting ? 'Saving...' : isEditing ? 'Save Changes' : 'Add Appointment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

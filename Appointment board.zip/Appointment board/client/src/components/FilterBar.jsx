import React from 'react';
import { Search, Calendar, Filter, RotateCcw, LayoutGrid, List, X } from 'lucide-react';
import { getTodayDateString } from '../utils/timeUtils';

export default function FilterBar({
  filters,
  onFilterChange,
  viewMode,
  onViewModeChange,
  onResetData,
  appointmentCounts = {}
}) {
  const todayStr = getTodayDateString();

  return (
    <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs mb-6 space-y-4">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Left: Status Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
          {[
            { key: 'all', label: 'All', count: appointmentCounts.all || 0 },
            { key: 'scheduled', label: 'Scheduled', count: appointmentCounts.scheduled || 0 },
            { key: 'completed', label: 'Completed', count: appointmentCounts.completed || 0 },
            { key: 'cancelled', label: 'Cancelled', count: appointmentCounts.cancelled || 0 }
          ].map(({ key, label, count }) => {
            const isActive = filters.status === key;
            return (
              <button
                key={key}
                onClick={() => onFilterChange({ ...filters, status: key })}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200/70 hover:text-slate-900'
                }`}
              >
                <span>{label}</span>
                <span
                  className={`text-[11px] px-1.5 py-0.2 rounded-full ${
                    isActive ? 'bg-indigo-700/60 text-white' : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Right: Search, Date Filter & View Switcher */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Search box */}
          <div className="relative min-w-[180px] sm:min-w-[220px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={filters.search || ''}
              onChange={(e) => onFilterChange({ ...filters, search: e.target.value })}
              placeholder="Search meetings, hosts..."
              className="w-full pl-9 pr-8 py-1.5 text-xs rounded-xl border border-slate-200 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            {filters.search && (
              <button
                onClick={() => onFilterChange({ ...filters, search: '' })}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
                aria-label="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Date Picker Filter */}
          <div className="flex items-center gap-1.5">
            <div className="relative">
              <input
                type="date"
                value={filters.date || ''}
                onChange={(e) => onFilterChange({ ...filters, date: e.target.value })}
                className="pl-3 pr-2 py-1.5 text-xs rounded-xl border border-slate-200 text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                title="Filter by specific date"
              />
            </div>

            {filters.date ? (
              <button
                onClick={() => onFilterChange({ ...filters, date: '' })}
                className="px-2.5 py-1.5 text-xs font-medium text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
                title="Clear date filter"
              >
                All Dates
              </button>
            ) : (
              <button
                onClick={() => onFilterChange({ ...filters, date: todayStr })}
                className="px-2.5 py-1.5 text-xs font-medium text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-xl transition-colors"
                title="Filter to today's appointments"
              >
                Today
              </button>
            )}
          </div>

          {/* View Mode Toggle: Board vs List */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => onViewModeChange('board')}
              className={`p-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 ${
                viewMode === 'board'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Kanban Board view"
            >
              <LayoutGrid className="w-4 h-4" />
              <span className="hidden sm:inline">Board</span>
            </button>
            <button
              onClick={() => onViewModeChange('list')}
              className={`p-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 ${
                viewMode === 'list'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Chronological List view"
            >
              <List className="w-4 h-4" />
              <span className="hidden sm:inline">List</span>
            </button>
          </div>

          {/* Reset Demo Data Button */}
          <button
            onClick={onResetData}
            className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 border border-slate-200 rounded-xl transition-colors"
            title="Reset to initial sample appointments"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

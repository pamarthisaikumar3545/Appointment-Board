import React from 'react';
import { Clock, Calendar, User, Check, Ban, Edit3, CheckCircle2, XCircle } from 'lucide-react';
import { formatTime12h, getDuration, getRelativeDateLabel } from '../utils/timeUtils';

export default function AppointmentCard({
  appointment,
  onEdit,
  onComplete,
  onCancel
}) {
  const { id, title, description, date, startTime, endTime, status, teamMember } = appointment;

  const isScheduled = status === 'scheduled';
  const isCompleted = status === 'completed';
  const isCancelled = status === 'cancelled';

  const duration = getDuration(startTime, endTime);
  const relativeDate = getRelativeDateLabel(date);

  return (
    <div
      className={`group relative rounded-2xl p-5 border transition-all duration-200 shadow-sm hover:shadow-md ${
        isCancelled
          ? 'bg-slate-50/70 border-slate-200/80 opacity-75'
          : isCompleted
          ? 'bg-emerald-50/20 border-emerald-100 hover:border-emerald-200'
          : 'bg-white border-slate-200/90 hover:border-indigo-200'
      }`}
    >
      {/* Top row: Badges & Relative Date */}
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Status Badge */}
          {isScheduled && (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-1.5 animate-pulse"></span>
              Scheduled
            </span>
          )}
          {isCompleted && (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
              <CheckCircle2 className="w-3 h-3 mr-1 text-emerald-600" />
              Completed
            </span>
          )}
          {isCancelled && (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-200">
              <XCircle className="w-3 h-3 mr-1 text-rose-600" />
              Cancelled
            </span>
          )}

          {/* Duration Badge */}
          {duration && (
            <span className="text-[11px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
              {duration}
            </span>
          )}
        </div>

        {/* Date Tag */}
        <div className="flex items-center gap-1 text-xs font-medium text-slate-600 bg-slate-100/80 px-2.5 py-1 rounded-lg">
          <Calendar className="w-3 h-3 text-slate-400" />
          <span>{relativeDate}</span>
        </div>
      </div>

      {/* Appointment Title */}
      <h3
        className={`font-semibold text-base mb-1.5 leading-snug ${
          isCancelled
            ? 'text-slate-500 line-through decoration-rose-300'
            : isCompleted
            ? 'text-slate-800'
            : 'text-slate-900 group-hover:text-indigo-600 transition-colors'
        }`}
      >
        {title}
      </h3>

      {/* Description */}
      {description && (
        <p className={`text-xs mb-3 line-clamp-2 ${isCancelled ? 'text-slate-400' : 'text-slate-600'}`}>
          {description}
        </p>
      )}

      {/* Timing and Attendee Details */}
      <div className="pt-2.5 border-t border-slate-100 flex flex-col gap-1.5 text-xs text-slate-600">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-slate-700 font-medium">
            <Clock className="w-3.5 h-3.5 text-indigo-500 flex-shrink-0" />
            <span>
              {formatTime12h(startTime)} – {formatTime12h(endTime)}
            </span>
          </div>

          {teamMember && (
            <div className="flex items-center gap-1 text-slate-500">
              <User className="w-3 h-3 text-slate-400" />
              <span className="truncate max-w-[120px]">{teamMember}</span>
            </div>
          )}
        </div>
      </div>

      {/* Actions footer */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-end gap-1.5">
        {isScheduled && (
          <>
            <button
              onClick={() => onComplete(id)}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-emerald-700 hover:bg-emerald-50 hover:text-emerald-800 transition-colors border border-transparent hover:border-emerald-200"
              title="Mark appointment as completed"
            >
              <Check className="w-3.5 h-3.5" />
              Complete
            </button>

            <button
              onClick={() => onCancel(id)}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-rose-600 hover:bg-rose-50 hover:text-rose-700 transition-colors border border-transparent hover:border-rose-200"
              title="Cancel appointment"
            >
              <Ban className="w-3.5 h-3.5" />
              Cancel
            </button>
          </>
        )}

        {!isCancelled && (
          <button
            onClick={() => onEdit(appointment)}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors border border-transparent hover:border-slate-200"
            title="Edit appointment details"
          >
            <Edit3 className="w-3.5 h-3.5" />
            Edit
          </button>
        )}
      </div>
    </div>
  );
}

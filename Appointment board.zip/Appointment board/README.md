# Appointment Board

A modern, responsive, and robust full-stack appointment scheduling board designed for small teams. This application makes it easy to view, schedule, update, complete, and cancel appointments with strict real-time conflict prevention and clear visual status indicators.

---

## Features

- **Kanban Board & Chronological List Views**:
  - **Board View**: 3 distinct status columns:
    - **Scheduled / Upcoming**: Active appointments with real-time status pulses.
    - **Completed**: Finished appointments with green badges and checkmarks.
    - **Cancelled**: Appointments that were cancelled remain visible with strikethrough styling, muted backgrounds, and clear red badges.
  - **List View**: Chronological timeline grouped by date with appointment counts.
- **Appointment Lifecycle**:
  - **Add Appointment**: Schedule with title, team member/host, date, start time, end time, and description.
  - **Edit Appointment**: Modify title, host, timing, or notes anytime.
  - **Mark Completed**: One-click action to transition an appointment to completed status.
  - **Cancel Appointment**: Mark appointment as cancelled while keeping its historical record visible on the board.
- **Strict Time Slot Conflict Prevention**:
  - Automatically prevents two appointments from using the same time slot on the same date.
  - Provides clear, actionable error messages identifying the exact conflicting meeting and its time range.
  - Real-time client-side conflict preview + server-side validation with `409 Conflict` HTTP status.
- **Smart Filtering & Search**:
  - Filter by specific date (with a single-click "Today" shortcut).
  - Filter by status tabs (All, Scheduled, Completed, Cancelled) with live counters.
  - Full-text search across titles, descriptions, and team members.
- **Clear Feedback & Notifications**:
  - Animated toast notification banners for success, info, and error events.
  - Real-time inline field validation (e.g. End time must be after Start time).
- **Demo Ready**:
  - Pre-seeded with sample appointments across today, tomorrow, and upcoming days.
  - "Reset Demo Data" button to instantly restore initial sample state for review.
- **Built-in Documentation**:
  - "How It Works & Assumptions" modal directly accessible in the UI.

---

## How It Works & Key Engineering Assumptions

### 1. Time Slot Overlap Algorithm
Two appointments $A$ and $B$ on the same date conflict if and only if their intervals overlap:
$$\text{Overlap} \iff (S_A < E_B) \land (S_B < E_A)$$
where $S$ is start time in minutes from midnight and $E$ is end time.

### 2. Back-to-Back Appointments
- If Meeting A ends at 11:00 AM and Meeting B starts at 11:00 AM ($E_A = S_B$), they do **not** conflict. Meeting boundaries can touch without overlapping.

### 3. Cancelled Appointments & Slot Availability
- Cancelled appointments remain visible on the board (as required), styled distinctly so team members have a transparent audit trail.
- Once cancelled, the time slot is freed up so the team can re-book the slot.

### 4. Single Shared Team Board
- The board represents a shared calendar or conference room for a small team. Time conflict prevention applies across all active team meetings.

### 5. Self-Exclusion on Updates
- When editing an existing appointment, the appointment itself is excluded from conflict checks so users can update title, host, or notes without triggering false conflict errors.

---

## Tech Stack

- **Frontend**:
  - React 18
  - Vite
  - Tailwind CSS
  - Lucide React (icons)
- **Backend**:
  - Node.js (v20+)
  - Express 4
  - RESTful API with structured HTTP status codes (`200`, `201`, `400`, `404`, `409`, `500`)
- **Storage**:
  - Thread-safe, atomic file-based JSON store (`server/data/appointments.json`)
- **Testing**:
  - Vitest + Supertest
  - 26 automated unit & integration test cases

---

## Getting Started

### Prerequisites
- Node.js (v18 or higher)
- npm (v9 or higher)

### Installation

```bash
# Install root dependencies
npm install

# Install server dependencies
cd server && npm install && cd ..

# Install client dependencies
cd client && npm install && cd ..
```

### Running the Application

#### Option 1: Full-Stack Production Mode (Single Port)
The Express server is pre-configured to serve both the REST API and the React production bundle:

```bash
# 1. Build the client bundle
npm run build --prefix client

# 2. Start the Express server
npm start --prefix server
```
Then open your browser at: **`http://localhost:5000`**

#### Option 2: Development Mode (Concurrent with Hot Reloading)
```bash
npm run dev
```
- Client runs at: **`http://localhost:5173`**
- Server runs at: **`http://localhost:5000`** (requests automatically proxied via Vite)

---

## Running Automated Tests

Run the test suite covering validation logic, conflict checks, back-to-back appointments, and API routes:

```bash
npm test --prefix server
```

Test coverage includes:
- `timeToMinutes` conversion for 24h times.
- `isOverlapping` interval collision detection.
- Back-to-back appointment boundary checks.
- Missing field and invalid date/time validation errors (`400 Bad Request`).
- Overlapping appointment conflict detection (`409 Conflict`).
- Cancelled appointment slot releasing and visibility.
- Filter tests (by date, status, and search query).
- Appointment status lifecycle transitions (`complete`, `cancel`).
- Data reset to sample state.

---

## API Documentation

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/appointments` | List appointments (supports `?date=`, `?status=`, `?search=`) |
| `GET` | `/api/appointments/:id` | Get single appointment by ID |
| `POST` | `/api/appointments` | Create new appointment with validation & conflict detection |
| `PUT` | `/api/appointments/:id` | Update existing appointment details |
| `PATCH`| `/api/appointments/:id/complete` | Mark appointment as completed |
| `PATCH`| `/api/appointments/:id/cancel` | Cancel appointment (keeps record, frees slot) |
| `POST` | `/api/appointments/reset` | Reset board to initial sample appointments |
| `GET` | `/api/health` | Health check endpoint |

import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { AppointmentService } from '../src/services/appointmentService.js';
import { createAppointmentRouter } from '../src/routes/appointments.js';
import express from 'express';

// In-memory mock store for isolated testing
class MockStore {
  constructor(initial = []) {
    this.initial = initial;
    this.data = JSON.parse(JSON.stringify(initial));
  }
  async getAll() {
    return [...this.data];
  }
  async save(items) {
    this.data = [...items];
  }
  async reset() {
    this.data = JSON.parse(JSON.stringify(this.initial));
    return [...this.data];
  }
}

describe('Appointment REST API Endpoints', () => {
  let app;
  let service;
  let mockStore;

  const sampleInitial = [
    {
      id: 'apt-1',
      title: 'Morning Standup',
      description: 'Daily team alignment',
      date: '2026-10-01',
      startTime: '09:00',
      endTime: '10:00',
      status: 'scheduled',
      teamMember: 'Alice'
    },
    {
      id: 'apt-2',
      title: 'Client Demo',
      description: 'Feature review with stakeholders',
      date: '2026-10-01',
      startTime: '11:00',
      endTime: '12:00',
      status: 'scheduled',
      teamMember: 'Bob'
    },
    {
      id: 'apt-3',
      title: 'Design Review',
      description: 'Figma review',
      date: '2026-10-02',
      startTime: '14:00',
      endTime: '15:00',
      status: 'completed',
      teamMember: 'Charlie'
    }
  ];

  beforeEach(() => {
    mockStore = new MockStore(sampleInitial);
    service = new AppointmentService(mockStore);
    
    app = express();
    app.use(express.json());
    app.use('/api/appointments', createAppointmentRouter(service));
    // Global error handler
    // eslint-disable-next-line no-unused-vars
    app.use((err, req, res, next) => {
      const status = err.status || 500;
      res.status(status).json({
        success: false,
        error: err.message,
        conflictingAppointment: err.conflictingAppointment
      });
    });
  });

  describe('GET /api/appointments', () => {
    it('returns all appointments sorted chronologically', async () => {
      const res = await request(app).get('/api/appointments');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.count).toBe(3);
      expect(res.body.data[0].id).toBe('apt-1');
    });

    it('filters by date correctly', async () => {
      const res = await request(app).get('/api/appointments?date=2026-10-01');
      expect(res.status).toBe(200);
      expect(res.body.count).toBe(2);
      expect(res.body.data.every(a => a.date === '2026-10-01')).toBe(true);
    });

    it('filters by status correctly', async () => {
      const res = await request(app).get('/api/appointments?status=completed');
      expect(res.status).toBe(200);
      expect(res.body.count).toBe(1);
      expect(res.body.data[0].title).toBe('Design Review');
    });

    it('filters by search keyword', async () => {
      const res = await request(app).get('/api/appointments?search=stakeholders');
      expect(res.status).toBe(200);
      expect(res.body.count).toBe(1);
      expect(res.body.data[0].id).toBe('apt-2');
    });
  });

  describe('POST /api/appointments', () => {
    it('creates a new appointment successfully when valid and no conflict exists', async () => {
      const newApt = {
        title: 'Lunch & Learn',
        description: 'Tech talk on WebSockets',
        date: '2026-10-01',
        startTime: '13:00',
        endTime: '14:00',
        teamMember: 'Dana'
      };

      const res = await request(app)
        .post('/api/appointments')
        .send(newApt);

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.data.title).toBe('Lunch & Learn');
      expect(res.body.data.status).toBe('scheduled');
      expect(res.body.data.id).toBeDefined();

      // Check it was persisted
      const list = await request(app).get('/api/appointments');
      expect(list.body.count).toBe(4);
    });

    it('rejects creation when required fields are missing', async () => {
      const res = await request(app)
        .post('/api/appointments')
        .send({
          description: 'No title or times'
        });

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error).toContain('Title is required');
    });

    it('rejects creation when end time is before start time', async () => {
      const res = await request(app)
        .post('/api/appointments')
        .send({
          title: 'Time travel meeting',
          date: '2026-10-01',
          startTime: '15:00',
          endTime: '14:00'
        });

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error).toContain('End time must be after start time');
    });

    it('prevents two appointments from using the same time slot (overlap conflict)', async () => {
      // apt-1 is on 2026-10-01 from 09:00 to 10:00
      const conflictingApt = {
        title: 'Overlapping Meeting',
        description: 'Should be rejected',
        date: '2026-10-01',
        startTime: '09:30',
        endTime: '10:30'
      };

      const res = await request(app)
        .post('/api/appointments')
        .send(conflictingApt);

      expect(res.status).toBe(409);
      expect(res.body.success).toBe(false);
      expect(res.body.error).toContain('Time slot conflict');
      expect(res.body.error).toContain('Morning Standup');
      expect(res.body.conflictingAppointment).toBeDefined();
      expect(res.body.conflictingAppointment.id).toBe('apt-1');
    });

    it('allows back-to-back appointments without conflict', async () => {
      // apt-1 ends at 10:00, this starts exactly at 10:00
      const adjacentApt = {
        title: 'Directly After Standup',
        date: '2026-10-01',
        startTime: '10:00',
        endTime: '11:00'
      };

      const res = await request(app)
        .post('/api/appointments')
        .send(adjacentApt);

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
    });
  });

  describe('PATCH /api/appointments/:id/complete and /cancel', () => {
    it('marks an appointment as completed', async () => {
      const res = await request(app).patch('/api/appointments/apt-1/complete');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.status).toBe('completed');

      const check = await request(app).get('/api/appointments/apt-1');
      expect(check.body.data.status).toBe('completed');
    });

    it('cancels an appointment and frees up its time slot for new bookings', async () => {
      // 1. Cancel apt-1 (09:00 - 10:00 on 2026-10-01)
      const cancelRes = await request(app).patch('/api/appointments/apt-1/cancel');
      expect(cancelRes.status).toBe(200);
      expect(cancelRes.body.data.status).toBe('cancelled');

      // 2. Verify cancelled appointment is still visible in the list
      const listRes = await request(app).get('/api/appointments');
      const foundCancelled = listRes.body.data.find(a => a.id === 'apt-1');
      expect(foundCancelled).toBeDefined();
      expect(foundCancelled.status).toBe('cancelled');

      // 3. Scheduling another appointment in the same time slot now succeeds
      const newBooking = {
        title: 'Replacement Slot Booking',
        date: '2026-10-01',
        startTime: '09:00',
        endTime: '10:00'
      };

      const bookRes = await request(app)
        .post('/api/appointments')
        .send(newBooking);

      expect(bookRes.status).toBe(201);
      expect(bookRes.body.success).toBe(true);
    });
  });

  describe('PUT /api/appointments/:id', () => {
    it('updates an appointment without triggering self-conflict', async () => {
      const res = await request(app)
        .put('/api/appointments/apt-1')
        .send({
          title: 'Updated Standup Title',
          date: '2026-10-01',
          startTime: '09:00',
          endTime: '10:00',
          description: 'Updated agenda'
        });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.title).toBe('Updated Standup Title');
    });

    it('prevents update if moving to an already occupied slot', async () => {
      // Trying to move apt-1 to 11:00-12:00 which conflicts with apt-2
      const res = await request(app)
        .put('/api/appointments/apt-1')
        .send({
          date: '2026-10-01',
          startTime: '11:15',
          endTime: '11:45'
        });

      expect(res.status).toBe(409);
      expect(res.body.error).toContain('Time slot conflict');
    });
  });

  describe('POST /api/appointments/reset', () => {
    it('resets data back to initial sample state', async () => {
      // Modify an appointment
      await request(app).patch('/api/appointments/apt-1/cancel');

      // Reset
      const resetRes = await request(app).post('/api/appointments/reset');
      expect(resetRes.status).toBe(200);
      expect(resetRes.body.success).toBe(true);

      const check = await request(app).get('/api/appointments/apt-1');
      expect(check.body.data.status).toBe('scheduled');
    });
  });
});

import { describe, it, expect } from 'vitest';
import { AppointmentService } from '../src/services/appointmentService.js';

describe('AppointmentService Validation & Overlap Logic', () => {
  const service = new AppointmentService();

  describe('timeToMinutes', () => {
    it('correctly converts 24h time to minutes', () => {
      expect(service.timeToMinutes('00:00')).toBe(0);
      expect(service.timeToMinutes('09:30')).toBe(570);
      expect(service.timeToMinutes('12:00')).toBe(720);
      expect(service.timeToMinutes('23:59')).toBe(1439);
    });

    it('returns NaN for invalid time strings', () => {
      expect(service.timeToMinutes('invalid')).toBeNaN();
      expect(service.timeToMinutes('25:00')).toBeNaN();
      expect(service.timeToMinutes('10:65')).toBeNaN();
      expect(service.timeToMinutes('')).toBeNaN();
      expect(service.timeToMinutes(null)).toBeNaN();
    });
  });

  describe('isOverlapping', () => {
    it('detects exact same time slot as overlapping', () => {
      expect(service.isOverlapping('10:00', '11:00', '10:00', '11:00')).toBe(true);
    });

    it('detects partial overlap (starts before, ends inside)', () => {
      expect(service.isOverlapping('09:30', '10:30', '10:00', '11:00')).toBe(true);
    });

    it('detects partial overlap (starts inside, ends after)', () => {
      expect(service.isOverlapping('10:30', '11:30', '10:00', '11:00')).toBe(true);
    });

    it('detects total containment', () => {
      expect(service.isOverlapping('09:00', '12:00', '10:00', '11:00')).toBe(true);
      expect(service.isOverlapping('10:00', '11:00', '09:00', '12:00')).toBe(true);
    });

    it('permits back-to-back appointments (touching boundary does not overlap)', () => {
      // Meeting A: 10:00 - 11:00, Meeting B: 11:00 - 12:00
      expect(service.isOverlapping('10:00', '11:00', '11:00', '12:00')).toBe(false);
      expect(service.isOverlapping('11:00', '12:00', '10:00', '11:00')).toBe(false);
    });

    it('returns false for completely disjoint time intervals', () => {
      expect(service.isOverlapping('09:00', '10:00', '14:00', '15:00')).toBe(false);
    });
  });

  describe('validatePayload', () => {
    it('fails when title is missing or empty', () => {
      const errors = service.validatePayload({
        title: '   ',
        date: '2026-09-15',
        startTime: '10:00',
        endTime: '11:00'
      });
      expect(errors).toContain('Title is required');
    });

    it('fails when date is invalid or missing', () => {
      const errors = service.validatePayload({
        title: 'Strategy Meeting',
        date: 'not-a-date',
        startTime: '10:00',
        endTime: '11:00'
      });
      expect(errors).toContain('A valid date in YYYY-MM-DD format is required');
    });

    it('fails when end time is before or equal to start time', () => {
      const errorsEqual = service.validatePayload({
        title: 'Quick Check',
        date: '2026-09-15',
        startTime: '10:00',
        endTime: '10:00'
      });
      expect(errorsEqual).toContain('End time must be after start time');

      const errorsBefore = service.validatePayload({
        title: 'Quick Check',
        date: '2026-09-15',
        startTime: '14:00',
        endTime: '13:00'
      });
      expect(errorsBefore).toContain('End time must be after start time');
    });

    it('passes for a valid appointment payload', () => {
      const errors = service.validatePayload({
        title: 'Team Sync',
        date: '2026-09-15',
        startTime: '14:00',
        endTime: '15:00',
        description: 'Sync on weekly goals'
      });
      expect(errors).toHaveLength(0);
    });
  });
});

import express from 'express';
import { defaultService } from '../services/appointmentService.js';

export function createAppointmentRouter(service = defaultService) {
  const router = express.Router();

  // GET /api/appointments - list with optional filters
  router.get('/', async (req, res, next) => {
    try {
      const { date, status, search } = req.query;
      const appointments = await service.getAppointments({ date, status, search });
      res.json({
        success: true,
        count: appointments.length,
        data: appointments
      });
    } catch (err) {
      next(err);
    }
  });

  // GET /api/appointments/:id - single appointment
  router.get('/:id', async (req, res, next) => {
    try {
      const appointment = await service.getAppointmentById(req.params.id);
      if (!appointment) {
        return res.status(404).json({
          success: false,
          error: 'Appointment not found'
        });
      }
      res.json({
        success: true,
        data: appointment
      });
    } catch (err) {
      next(err);
    }
  });

  // POST /api/appointments - create appointment
  router.post('/', async (req, res, next) => {
    try {
      const created = await service.createAppointment(req.body);
      res.status(201).json({
        success: true,
        message: 'Appointment successfully scheduled',
        data: created
      });
    } catch (err) {
      next(err);
    }
  });

  // PUT /api/appointments/:id - update appointment
  router.put('/:id', async (req, res, next) => {
    try {
      const updated = await service.updateAppointment(req.params.id, req.body);
      res.json({
        success: true,
        message: 'Appointment successfully updated',
        data: updated
      });
    } catch (err) {
      next(err);
    }
  });

  // PATCH /api/appointments/:id/complete - mark as completed
  router.patch('/:id/complete', async (req, res, next) => {
    try {
      const completed = await service.completeAppointment(req.params.id);
      res.json({
        success: true,
        message: 'Appointment marked as completed',
        data: completed
      });
    } catch (err) {
      next(err);
    }
  });

  // PATCH /api/appointments/:id/cancel - cancel appointment
  router.patch('/:id/cancel', async (req, res, next) => {
    try {
      const cancelled = await service.cancelAppointment(req.params.id);
      res.json({
        success: true,
        message: 'Appointment cancelled successfully',
        data: cancelled
      });
    } catch (err) {
      next(err);
    }
  });

  // POST /api/appointments/reset - reset to sample appointments
  router.post('/reset', async (req, res, next) => {
    try {
      const resetData = await service.resetToSample();
      res.json({
        success: true,
        message: 'Appointments reset to initial sample data',
        count: resetData.length,
        data: resetData
      });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

export default createAppointmentRouter();

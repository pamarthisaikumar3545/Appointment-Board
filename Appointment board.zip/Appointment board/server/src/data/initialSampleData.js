/**
 * Generates initial sample appointments dynamically relative to the current date.
 * This guarantees the board always has relevant "Today", "Tomorrow", and "Upcoming"
 * appointments when opened or reset.
 */

function formatDate(d) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getSampleAppointments() {
  const today = new Date();
  
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);

  const tomorrow = new Date(today);
  tomorrow.setDate(today.getDate() + 1);

  const inTwoDays = new Date(today);
  inTwoDays.setDate(today.getDate() + 2);

  const todayStr = formatDate(today);
  const yesterdayStr = formatDate(yesterday);
  const tomorrowStr = formatDate(tomorrow);
  const inTwoDaysStr = formatDate(inTwoDays);

  return [
    {
      id: 'apt-1',
      title: 'Q3 Product Roadmap Sync',
      description: 'Review product milestones, sprint goals, and resource allocation with engineering leads.',
      date: todayStr,
      startTime: '09:30',
      endTime: '10:30',
      status: 'scheduled',
      teamMember: 'Sarah Jenkins',
      createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 24).toISOString()
    },
    {
      id: 'apt-2',
      title: 'Client Demo: Acme Corp',
      description: 'Present the new analytics dashboard features to Acme Corp stakeholder team.',
      date: todayStr,
      startTime: '11:00',
      endTime: '12:00',
      status: 'scheduled',
      teamMember: 'Alex Rivera',
      createdAt: new Date(Date.now() - 3600000 * 20).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 20).toISOString()
    },
    {
      id: 'apt-3',
      title: 'Team Standup & Daily Huddle',
      description: 'Quick morning sync on blockers, PR reviews, and daily deliverables.',
      date: todayStr,
      startTime: '08:30',
      endTime: '09:00',
      status: 'completed',
      teamMember: 'Team Entire',
      createdAt: new Date(Date.now() - 3600000 * 30).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 4).toISOString()
    },
    {
      id: 'apt-4',
      title: 'Vendor Contract Negotiation',
      description: 'Annual SaaS tooling license review. Cancelled due to vendor reschedule request.',
      date: todayStr,
      startTime: '14:00',
      endTime: '15:00',
      status: 'cancelled',
      teamMember: 'David Kim',
      createdAt: new Date(Date.now() - 3600000 * 15).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 2).toISOString()
    },
    {
      id: 'apt-5',
      title: 'Architecture Review: Microservices',
      description: 'Deep dive into event-driven pub/sub architecture and Redis caching tier.',
      date: tomorrowStr,
      startTime: '10:00',
      endTime: '11:30',
      status: 'scheduled',
      teamMember: 'Elena Rostova',
      createdAt: new Date(Date.now() - 3600000 * 10).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 10).toISOString()
    },
    {
      id: 'apt-6',
      title: '1-on-1 Mentorship Session',
      description: 'Bi-weekly career growth and engineering check-in.',
      date: tomorrowStr,
      startTime: '15:00',
      endTime: '16:00',
      status: 'scheduled',
      teamMember: 'Marcus Vance',
      createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 8).toISOString()
    },
    {
      id: 'apt-7',
      title: 'Sprint Retrospective',
      description: 'Celebrate wins, analyze bottlenecks, and document action items for next sprint.',
      date: yesterdayStr,
      startTime: '16:00',
      endTime: '17:00',
      status: 'completed',
      teamMember: 'Team Entire',
      createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 24).toISOString()
    },
    {
      id: 'apt-8',
      title: 'Security Vulnerability Audit',
      description: 'Review dependency scan alerts and update core packages.',
      date: inTwoDaysStr,
      startTime: '13:00',
      endTime: '14:30',
      status: 'scheduled',
      teamMember: 'David Kim',
      createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 5).toISOString()
    }
  ];
}

import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getSampleAppointments } from '../data/initialSampleData.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DEFAULT_DATA_PATH = path.resolve(__dirname, '../../data/appointments.json');

export class FileStore {
  constructor(filePath = DEFAULT_DATA_PATH) {
    this.filePath = filePath;
    this.initialized = false;
  }

  async init() {
    try {
      const dir = path.dirname(this.filePath);
      await fs.mkdir(dir, { recursive: true });
      try {
        await fs.access(this.filePath);
        // Verify valid json content
        const content = await fs.readFile(this.filePath, 'utf8');
        JSON.parse(content);
      } catch {
        // File doesn't exist or corrupted, seed sample data
        const initialData = getSampleAppointments();
        await this.save(initialData);
      }
      this.initialized = true;
    } catch (err) {
      console.error('Error initializing file store:', err);
      throw err;
    }
  }

  async getAll() {
    if (!this.initialized) await this.init();
    try {
      const content = await fs.readFile(this.filePath, 'utf8');
      return JSON.parse(content);
    } catch (err) {
      // Fallback if read failed
      const fresh = getSampleAppointments();
      await this.save(fresh);
      return fresh;
    }
  }

  async save(appointments) {
    const dir = path.dirname(this.filePath);
    await fs.mkdir(dir, { recursive: true });
    // Write atomically via temporary file to prevent corruption
    const tempPath = `${this.filePath}.${Date.now()}.tmp`;
    await fs.writeFile(tempPath, JSON.stringify(appointments, null, 2), 'utf8');
    await fs.rename(tempPath, this.filePath);
  }

  async reset() {
    const sample = getSampleAppointments();
    await this.save(sample);
    return sample;
  }
}

export const defaultStore = new FileStore();

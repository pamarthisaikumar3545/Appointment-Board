import crypto from 'node:crypto';
import { defaultStore } from '../storage/fileStore.js';

export class AppointmentService {
  constructor(store = defaultStore) {
    this.store = store;
  }

  /**
   * Helper: converts "HH:MM" string to minutes from midnight
   */
  timeToMinutes(timeStr) {
    if (!timeStr || typeof timeStr !== 'string') return NaN;
    const parts = timeStr.trim().split(':');
    if (parts.length !== 2) return NaN;
    const hours = parseInt(parts[0], 10);
    const minutes = parseInt(parts[1], 10);
    if (isNaN(hours) || isNaN(minutes)) return NaN;
    if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) return NaN;
    return hours * 60 + minutes;
  }

  /**
   * Checks if two time intervals overlap.
   * Note: Touching intervals (e.g. 10:00-11:00 and 11:00-12:00) do NOT overlap.
   */
  isOverlapping(start1, end1, start2, end2) {
    const s1 = this.timeToMinutes(start1);
    const e1 = this.timeToMinutes(end1);
    const s2 = this.timeToMinutes(start2);
    const e2 = this.timeToMinutes(end2);

    if (isNaN(s1) || isNaN(e1) || isNaN(s2) || isNaN(e2)) {
      return false;
    }

    return s1 < e2 && s2 < e1;
  }

  /**
   * Validates appointment payload fields
   */
  validatePayload(payload) {
    const errors = [];
    const { title, date, startTime, endTime } = payload;

    if (!title || typeof title !== 'string' || !title.trim()) {
      errors.push('Title is required');
    }

    if (!date || typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date.trim())) {
      errors.push('A valid date in YYYY-MM-DD format is required');
    }

    const startMin = this.timeToMinutes(startTime);
    const endMin = this.timeToMinutes(endTime);

    if (isNaN(startMin)) {
      errors.push('A valid start time in HH:MM (24h) format is required');
    }

    if (isNaN(endMin)) {
      errors.push('A valid end time in HH:MM (24h) format is required');
    }

    if (!isNaN(startMin) && !isNaN(endMin)) {
      if (endMin <= startMin) {
        errors.push('End time must be after start time');
      }
    }

    return errors;
  }

  /**
   * Checks for time slot collisions on the same date.
   * Excludes cancelled appointments because cancelled appointments free up their slot.
   * If excludeId is provided, excludes that appointment (for updates).
   */
  async findConflictingAppointment(date, startTime, endTime, excludeId = null) {
    const appointments = await this.store.getAll();
    const cleanDate = date.trim();

    return appointments.find(apt => {
      // Must be on same date
      if (apt.date !== cleanDate) return false;
      // Skip the appointment itself if updating
      if (excludeId && apt.id === excludeId) return false;
      // Cancelled appointments do not block the time slot
      if (apt.status === 'cancelled') return false;

      return this.isOverlapping(startTime, endTime, apt.startTime, apt.endTime);
    });
  }

  /**
   * Retrieves all appointments with optional filtering and sorting
   */
  async getAppointments(filters = {}) {
    let list = await this.store.getAll();

    if (filters.date) {
      const targetDate = filters.date.trim();
      list = list.filter(apt => apt.date === targetDate);
    }

    if (filters.status && filters.status !== 'all') {
      const targetStatus = filters.status.trim().toLowerCase();
      list = list.filter(apt => apt.status.toLowerCase() === targetStatus);
    }

    if (filters.search) {
      const query = filters.search.trim().toLowerCase();
      list = list.filter(apt =>
        (apt.title && apt.title.toLowerCase().includes(query)) ||
        (apt.description && apt.description.toLowerCase().includes(query)) ||
        (apt.teamMember && apt.teamMember.toLowerCase().includes(query))
      );
    }

    // Sort chronologically: by date ascending, then startTime ascending
    list.sort((a, b) => {
      if (a.date !== b.date) {
        return a.date.localeCompare(b.date);
      }
      return a.startTime.localeCompare(b.startTime);
    });

    return list;
  }

  /**
   * Retrieves a single appointment by ID
   */
  async getAppointmentById(id) {
    const appointments = await this.store.getAll();
    return appointments.find(apt => apt.id === id) || null;
  }

  /**
   * Creates a new appointment
   */
  async createAppointment(data) {
    const errors = this.validatePayload(data);
    if (errors.length > 0) {
      const err = new Error(errors.join(', '));
      err.status = 400;
      err.errors = errors;
      throw err;
    }

    const conflict = await this.findConflictingAppointment(data.date, data.startTime, data.endTime);
    if (conflict) {
      const err = new Error(
        `Time slot conflict: The selected time overlaps with "${conflict.title}" (${conflict.startTime} - ${conflict.endTime}).`
      );
      err.status = 409;
      err.conflictingAppointment = conflict;
      throw err;
    }

    const appointments = await this.store.getAll();
    const newAppointment = {
      id: crypto.randomUUID(),
      title: data.title.trim(),
      description: (data.description || '').trim(),
      date: data.date.trim(),
      startTime: data.startTime.trim(),
      endTime: data.endTime.trim(),
      status: 'scheduled',
      teamMember: (data.teamMember || 'Unassigned').trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    appointments.push(newAppointment);
    await this.store.save(appointments);
    return newAppointment;
  }

  /**
   * Updates an existing appointment
   */
  async updateAppointment(id, data) {
    const appointments = await this.store.getAll();
    const index = appointments.findIndex(apt => apt.id === id);
    if (index === -1) {
      const err = new Error('Appointment not found');
      err.status = 404;
      throw err;
    }

    const current = appointments[index];

    // Merged data for validation
    const updatedData = {
      title: data.title !== undefined ? data.title : current.title,
      description: data.description !== undefined ? data.description : current.description,
      date: data.date !== undefined ? data.date : current.date,
      startTime: data.startTime !== undefined ? data.startTime : current.startTime,
      endTime: data.endTime !== undefined ? data.endTime : current.endTime,
      teamMember: data.teamMember !== undefined ? data.teamMember : current.teamMember,
      status: data.status !== undefined ? data.status : current.status
    };

    const errors = this.validatePayload(updatedData);
    if (errors.length > 0) {
      const err = new Error(errors.join(', '));
      err.status = 400;
      err.errors = errors;
      throw err;
    }

    // Check conflict only if status is not cancelled
    if (updatedData.status !== 'cancelled') {
      const conflict = await this.findConflictingAppointment(
        updatedData.date,
        updatedData.startTime,
        updatedData.endTime,
        id
      );
      if (conflict) {
        const err = new Error(
          `Time slot conflict: The selected time overlaps with "${conflict.title}" (${conflict.startTime} - ${conflict.endTime}).`
        );
        err.status = 409;
        err.conflictingAppointment = conflict;
        throw err;
      }
    }

    const updatedAppointment = {
      ...current,
      ...updatedData,
      title: updatedData.title.trim(),
      description: (updatedData.description || '').trim(),
      date: updatedData.date.trim(),
      startTime: updatedData.startTime.trim(),
      endTime: updatedData.endTime.trim(),
      teamMember: (updatedData.teamMember || 'Unassigned').trim(),
      updatedAt: new Date().toISOString()
    };

    appointments[index] = updatedAppointment;
    await this.store.save(appointments);
    return updatedAppointment;
  }

  /**
   * Marks an appointment as completed
   */
  async completeAppointment(id) {
    const appointments = await this.store.getAll();
    const index = appointments.findIndex(apt => apt.id === id);
    if (index === -1) {
      const err = new Error('Appointment not found');
      err.status = 404;
      throw err;
    }

    appointments[index] = {
      ...appointments[index],
      status: 'completed',
      updatedAt: new Date().toISOString()
    };

    await this.store.save(appointments);
    return appointments[index];
  }

  /**
   * Cancels an appointment (remains in system as cancelled)
   */
  async cancelAppointment(id) {
    const appointments = await this.store.getAll();
    const index = appointments.findIndex(apt => apt.id === id);
    if (index === -1) {
      const err = new Error('Appointment not found');
      err.status = 404;
      throw err;
    }

    appointments[index] = {
      ...appointments[index],
      status: 'cancelled',
      updatedAt: new Date().toISOString()
    };

    await this.store.save(appointments);
    return appointments[index];
  }

  /**
   * Resets database back to sample data
   */
  async resetToSample() {
    return await this.store.reset();
  }
}

export const defaultService = new AppointmentService();

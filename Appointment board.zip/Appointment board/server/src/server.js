import app from './app.js';
import { defaultStore } from './storage/fileStore.js';

const PORT = process.env.PORT || 5000;

async function startServer() {
  try {
    await defaultStore.init();
    console.log('Appointments file store initialized.');

    app.listen(PORT, () => {
      console.log(`Appointment Board Server running on http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

startServer();
